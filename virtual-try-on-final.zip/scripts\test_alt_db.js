const { Client } = require('pg');

const url = "postgresql://postgres.yprkvpofnbbpxcffwtpf:CRICTURF%40123@aws-0-us-east-1.pooler.supabase.com:6543/postgres?pgbouncer=true";

async function test() {
    console.log(`Testing with ID yprkvpofnbbpxcffwtpf...`);
    const client = new Client({
        connectionString: url,
    });
    try {
        await client.connect();
        console.log(`Success!`);
        const res = await client.query('SELECT NOW()');
        console.log(`Result:`, res.rows[0]);
        await client.end();
    } catch (err) {
        console.error(`Failed:`, err.message);
    }
}

test();
