require('dotenv').config({ path: '.env' });

async function listModels() {
    const apiKey = process.env.GEMINI_API_KEY;
    console.log("Testing API Key:", apiKey ? apiKey.substring(0, 10) + "..." : "Not Found");

    const url = `https://generativelanguage.googleapis.com/v1beta/models?key=${apiKey}`;

    try {
        const response = await fetch(url, {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });

        const data = await response.json();

        if (!response.ok) {
            console.error("API Error:", JSON.stringify(data, null, 2));
        } else {
            // Filter for models that support generateContent
            const models = data.models
                ?.filter(m => m.supportedGenerationMethods?.includes('generateContent'))
                .map(m => m.name);
            console.log("Available Models:", JSON.stringify(models, null, 2));
        }
    } catch (error) {
        console.error("Network/Script Error:", error);
    }
}

listModels();
