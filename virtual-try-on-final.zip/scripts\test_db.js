const { Client } = require('pg');
require('dotenv').config();

async function testConnection(url, name) {
    console.log(`Testing ${name}...`);
    const client = new Client({
        connectionString: url,
    });
    try {
        await client.connect();
        console.log(`${name} connected successfully!`);
        const res = await client.query('SELECT NOW()');
        console.log(`${name} result:`, res.rows[0]);
        await client.end();
    } catch (err) {
        console.error(`${name} failed:`, err.message);
    }
}

async function run() {
    await testConnection(process.env.DATABASE_URL, 'DATABASE_URL (Pooler)');
    await testConnection(process.env.DIRECT_URL, 'DIRECT_URL');
}

run();
