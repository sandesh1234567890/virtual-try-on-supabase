import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
    if (!OPENAI_API_KEY) return NextResponse.json({ error: "API Key missing" }, { status: 500 });

    try {
        const { messages, image } = await req.json();

        // 1. Fetch dynamic products
        const dbProducts = await prisma.product.findMany();

        // 2. Format products for the AI catalog
        const formattedCatalog = {
            tops: dbProducts.filter(p => {
                const cat = p.category.toLowerCase();
                return cat.includes('top') || cat.includes('hoodie') || cat.includes('shirt') || cat.includes('jacket') || cat.includes('coat') || cat.includes('t-shirt');
            }).map(p => ({ id: p.id, name: p.name, category: p.category })),
            bottoms: dbProducts.filter(p => {
                const cat = p.category.toLowerCase();
                return cat.includes('bottom') || cat.includes('pant') || cat.includes('denim') || cat.includes('jeans') || cat.includes('slacks');
            }).map(p => ({ id: p.id, name: p.name, category: p.category })),
            shoes: dbProducts.filter(p => {
                const cat = p.category.toLowerCase();
                return cat.includes('shoe') || cat.includes('boot') || cat.includes('runner') || cat.includes('kicks');
            }).map(p => ({ id: p.id, name: p.name, category: p.category })),
            suits: dbProducts.filter(p => p.category.toLowerCase().includes('suit')).map(p => ({ id: p.id, name: p.name, category: p.category })),
            dresses: dbProducts.filter(p => p.category.toLowerCase().includes('dress')).map(p => ({ id: p.id, name: p.name, category: p.category })),
        };

        const SYSTEM_PROMPT = `You are the Dragon Stylist, the high-end virtual salesperson for Dragon Studio.

Persona: Proactive, tech-savvy, and persuasive. You don't just answer; you guide the user's style journey.

Marketing Goals:
1. Pitch "Dragon Studio" (/dragon) for multi-garment outfit "Ignition" and advanced custom uploads.
2. Pitch "V-ROUND 360° Studio" (/v-round) for creating immersive, cinematic videos of their looks.

App Guidance:
If users are lost, explain the flow: 
1. Select a Garment from the catalog or Chatbot.
2. Go to Dragon Studio (/dragon).
3. Upload your Photo in the Scanner.
4. "Ignite Combo" to see the neural result.

"Show Me" Logic:
When a user asks to see specific items (e.g., "show me red shirts", "show me suits"), you MUST return the corresponding IDs in the SUGGESTIONS block. Acknowledge the request politely.

Format & Tags:
- No bolding, no headers. Clean text only.
- Navigation: If you suggest moving to a specific page, append [[NAVIGATE: /path]].
- Suggestions: Always end with [[SUGGESTIONS: {"tops":["ID"],"bottoms":["ID"],"shoes":["ID"],"suits":["ID"],"dresses":["ID"]}]]
- Ensure "bottoms" is used instead of "pants" in the JSON keys.

Catalog: ${JSON.stringify(formattedCatalog)}`;

        // Balanced Optimization: 10 messages for better context depth
        const trimmedHistory = messages.slice(-10);

        const processedMessages = trimmedHistory.map((m: any, idx: number) => {
            if (m.role === 'user' && image && idx === trimmedHistory.length - 1) {
                return {
                    role: 'user',
                    content: [{ type: 'text', text: m.content || "Analyze this." }, { type: 'image_url', image_url: { url: image } }]
                };
            }
            return m;
        });

        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${OPENAI_API_KEY}`
            },
            body: JSON.stringify({
                model: 'gpt-4o',
                messages: [{ role: 'system', content: SYSTEM_PROMPT }, ...processedMessages],
                temperature: 0.7,
                max_tokens: 400
            })
        });

        if (!response.ok) {
            const error = await response.json();
            return NextResponse.json({ error: error.error?.message || "OpenAI Error" }, { status: response.status });
        }

        const data = await response.json();
        return NextResponse.json(data);
    } catch (error: any) {
        console.error("Chat API error:", error);
        return NextResponse.json({ error: error.message }, { status: 500 });
    }
}
